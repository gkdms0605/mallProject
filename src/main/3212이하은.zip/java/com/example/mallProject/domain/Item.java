package com.example.mallProject.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
public class Item {
    @Id
    private Long itemId;

    private String itemName;
    private String itemDetail;
    private int stockNum;
    private int price;
    //    private String imgNum;

    public Item(String itemName, String itemDetail, int stockNum, int price){
        this.itemName = itemName;
        this.itemDetail = itemDetail;
        this.stockNum = stockNum;
        this.price = price;
        //        this.imgNum = imgNum;
    }
}
