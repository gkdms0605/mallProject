package com.example.mallProject.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ItemController {

}
