package com.example.mallProject.service;

import com.example.mallProject.domain.Item;
import com.example.mallProject.dto.ItemAddDto;
import com.example.mallProject.dto.ItemUpdateDto;
import com.example.mallProject.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ItemService {
    @Autowired
    private ItemRepository itemRepository;

    // 물품 조회
    public Item getItem(Long ItemId){

        Item item = itemRepository.findById(ItemId).orElse(null);

        // 예외처리 (해당 id가 없을 경우)
        if(item == null){
            throw new IllegalArgumentException("상품이 존재하지 않습니다.");
        }

        return item;
    }

    // 물품 추가
    public Item addItem(ItemAddDto dto){

        Item item = new Item(
                dto.getItemName(),
                dto.getItemDetail(),
                dto.getStockNum(),
                dto.getPrice()
        );

        return itemRepository.save(item);
    }

    //물품 정보 수정
    public String updateItem(Long itemId, ItemUpdateDto dto){

        Item item = itemRepository.findById(itemId).orElse(null);

        if(item == null){
            throw new IllegalArgumentException("상품이 존재하지 않습니다.");
        }

        item.setItemName(dto.getItemName());
        item.setItemDetail(dto.getItemDetail());
        item.setPrice(dto.getPrice());
        item.setStockNum(dto.getStockNum());

        itemRepository.save(item);

        return "상품 수정이 완료되었습니다.";
    }

    // 물품 정보 삭제
    // public String deleteItem(Long itemId, ItemDeleteDto dto){}
}
